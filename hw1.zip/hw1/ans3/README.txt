โปรแกรมจะรับinputชื่อไฟล์เป็นargument และแสดงoutputออกมากทางcommandเป็นexpression
tree โดยtreeที่ได้ขึ้นมานั้น จะบ่งบอกprecedenceของoperationต่างๆ
ซึ่งสังเกตได้จากชั้นหรือlevelของtreeที่ได้ โดยในชั้นที่อยู่ต่ำจะมีprecedenceสูง
และในชั้นที่สูงจะมีprecedenceต่ำ
